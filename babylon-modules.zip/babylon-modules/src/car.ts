import * as B from 'babylonjs';
// import skin from './img/car-mat.png' 
// import { createWheels } from "./wheels";

export function buildCar(scene: B.Scene): BABYLON.AbstractMesh {
    //We will first create the shape/outline of the mesh for the car. This will consist of an array of Vector3's which will be a horizontal line for the base, a quarter circle and horizontal line for the front/top (will be the same vector3). ?*The vertical back will be formed by the "extrudePolygon" method as it automatically joins the first and last point*?

    //Define the array, first add the Vector3's for the Horizontal Base:
    const outline = [
        new BABYLON.Vector3(-0.3, 0, -0.1),
        new BABYLON.Vector3(0.2, 0, -0.1),
    ];

    //Curved Front Vector3, add it to array:
    for (let i = 0; i < 20; i++) {
        outline.push(
            new BABYLON.Vector3(
                0.2 * Math.cos((i * Math.PI) / 40),
                0,
                0.2 * Math.sin((i * Math.PI) / 40) - 0.1
            )
        );
    }

    //Vector 3 for the Top, add to array:
    outline.push(new BABYLON.Vector3(0, 0, 0.1));
    outline.push(new BABYLON.Vector3(-0.3, 0, 0.1));

    //BEFORE PASSING THE OUTLINE[] TO THE CONSTRUCTOR OF EXTRUDEPOLYGON, WE WILL DEFINE THE MATHEMATICAL DIMENSIONS VIA VECTOR4[], AND PASS THIS TO THE EXTRUDEPOLYGON CONSTRUCTOR, THEN DEFINE THE MATERIAL TO BE USED ON THE CAR:EXTRUDEPOLYGON

    //DEFINE FACEUV MEASUREMENTS FOR CAR MATERIAL:
    //Extruded polygons have 3 sides indicated as: face0 is the top, face2 is the bottom and face 1 is the conjoining of the two:
    const faceUV = [];

    //Top of the car:
    faceUV[0] = new BABYLON.Vector4(0, 0.5, 0.38, 1);
    //Bottom of the car:
    faceUV[2] = new BABYLON.Vector4(0.38, 1, 0, 0.5);
    //The edge runs from (0, 0) to (1, 0.5):
    faceUV[1] = new BABYLON.Vector4(0, 1, 0, 0.5);

    //Define material for the car
    const carMat = new BABYLON.StandardMaterial("carMat");
    carMat.diffuseTexture = new BABYLON.Texture('./img/car-mat.png');


    //Pass the outline[] and faceUV[] to the constructor of ExtrudePolygon to make the car: ExtrudePolygon needs the appropriate cdn or import. It needs "earcut" cdn defined in index.html
    const car : BABYLON.AbstractMesh = BABYLON.MeshBuilder.ExtrudePolygon("car", {
        shape: outline,
        depth: 0.2,
        faceUV: faceUV,
        wrap: true,
    });
    //Apply car material:
    car.material = carMat;

    //CREATE CAR ANIMATIONS:
    //Define the animation object: define its name, the property to animate, the framerate, etc.
    const animCar = new BABYLON.Animation("carAnimation", "position.x", 30, BABYLON.Animation.ANIMATIONTYPE_FLOAT, BABYLON.Animation.ANIMATIONLOOPMODE_CYCLE);

    //Create the array of keyframe positions:
    const carKeys = [];

    carKeys.push({
        frame: 0,
        value: -10
    });

    carKeys.push({
        frame: 150,
        value: 10
    });
    
    carKeys.push({
        frame: 210,
        value: 10
    });

    //Set the keys for the animation object:
    animCar.setKeys(carKeys);

    //Add the animation object to the car's animations []. We can create multiple animation objects if neccessary then add each accordingly.
    car.animations = [];
    car.animations.push(animCar); 

    //RE-POSITION CAR:
    car.rotation = new BABYLON.Vector3(-Math.PI / 2, -Math.PI / 2, Math.PI / 2);

    car.position._y = 0.16;
    car.position._x = 10  ;

    //Let the scene play the animations:
    scene.beginAnimation(car, 9, 210, true);



    

    //BUILD WHEELS:
    createWheels(car, scene);

    return car;
}

const createWheels = (car: BABYLON.AbstractMesh, scene: B.Scene) => {
    //Define wheelUV face dimensions:
    //Cylinders are 3 sides: face0 is the bottom, face2 is the top, and face1 is the edge joining the bottom and top
    const wheelUV = [];
    wheelUV[0] = new BABYLON.Vector4(0, 0, 1, 1);
    wheelUV[1] = new BABYLON.Vector4(0, 0.5, 0, 0.5);
    wheelUV[2] = new BABYLON.Vector4(0, 0, 1, 1);

    //Create wheel material:
    const wheelMat = new BABYLON.StandardMaterial("wheelMat");
    wheelMat.diffuseTexture = new BABYLON.Texture("./img/wheel-mat.png");

    //CREATE WHEELS: We will create the rear right wheel and make it a child of the car. We will then clone it and change the position to where it should be for other wheels. Each clone will have the same parent.
    const wheelRB = BABYLON.MeshBuilder.CreateCylinder("wheelRB", {
        diameter: 0.125,
        height: 0.05,
    });
    //Apply wheel material:
    wheelRB.material = wheelMat;
    wheelRB.parent = car;
    wheelRB.position.z = -0.1;
    wheelRB.position.x = -0.2;
    wheelRB.position.y = 0.035;

    const wheelRF = wheelRB.clone("wheelRF");
    wheelRF.position.x = 0.1;

    const wheelLB = wheelRB.clone("wheelLB");
    wheelLB.position.y = -0.2 - 0.035;

    const wheelLF = wheelRF.clone("wheelLF");
    wheelLF.position.y = -0.2 - 0.035;


    /********** ANIMATE WHEELS ******************/
    //ANIMATE WHEELS:
    const animWheel = new BABYLON.Animation(
        "wheelAnimation",
        "rotation.y",
        30,
        BABYLON.Animation.ANIMATIONTYPE_FLOAT,
        BABYLON.Animation.ANIMATIONLOOPMODE_CYCLE
      );
    
      //Define the animation keyframe array that hold values for the properties of the mesh we want to see animated. 30 frames per second
      const wheelKeys = [];
      //At the animation keyframe of 0, the value of rotation.y will be 0:
      wheelKeys.push({
        frame: 0,
        value: 0,
      });
      //At the animation keyframe of 30, 1 second since 30 fps, the rotation.y value of 2PI making a complete roation
      wheelKeys.push({
        frame: 30,
        value: 2 * Math.PI,
      });
    
      //Apply keyFrame array to the wheel:
    
      //Attach the keyframe object to our BABYLON.Animation object:
      animWheel.setKeys(wheelKeys);
      //Apply animation object to each wheel. We will create an array to hold our animations. For now will just have the wheel's animation.
      wheelRB.animations = [];
      wheelRB.animations.push(animWheel);
      wheelLB.animations = [];
      wheelLB.animations.push(animWheel);
      wheelLF.animations = [];
      wheelLF.animations.push(animWheel);
      wheelRF.animations = [];
      wheelRF.animations.push(animWheel);
    
      //BEGIN THE ANIMATIONS:
      scene.beginAnimation(wheelRB, 0, 30, true);
      scene.beginAnimation(wheelLB, 0, 30, true);
      scene.beginAnimation(wheelRF, 0, 30, true);
      scene.beginAnimation(wheelLF, 0, 30, true);
}

