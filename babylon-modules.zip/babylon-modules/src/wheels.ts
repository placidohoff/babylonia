import * as B from '@babylonjs/core'

export function createWheels(car :BABYLON.Mesh){
    //Define wheelUV face dimensions:
  //Cylinders are 3 sides: face0 is the bottom, face2 is the top, and face1 is the edge joining the bottom and top
  const wheelUV = [];
  wheelUV[0] = new BABYLON.Vector4(0, 0, 1, 1);
  wheelUV[1] = new BABYLON.Vector4(0, 0.5, 0, 0.5);
  wheelUV[2] = new BABYLON.Vector4(0, 0, 1, 1);

  //Create wheel material:
  const wheelMat = new BABYLON.StandardMaterial("wheelMat");
  wheelMat.diffuseTexture = new BABYLON.Texture("./img/wheel-mat.png");

  //CREATE WHEELS: We will create the rear right wheel and make it a child of the car. We will then clone it and change the position to where it should be for other wheels. Each clone will have the same parent.
  const wheelRB = BABYLON.MeshBuilder.CreateCylinder("wheelRB", {
    diameter: 0.125,
    height: 0.05,
  });
  //Apply wheel material:
  wheelRB.material = wheelMat;
  wheelRB.parent = car;
  wheelRB.position.z = -0.1;
  wheelRB.position.x = -0.2;
  wheelRB.position.y = 0.035;

  const wheelRF = wheelRB.clone("wheelRF");
  wheelRF.position.x = 0.1;

  const wheelLB = wheelRB.clone("wheelLB");
  wheelLB.position.y = -0.2 - 0.035;

  const wheelLF = wheelRF.clone("wheelLF");
  wheelLF.position.y = -0.2 - 0.035;
}