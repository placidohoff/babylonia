import * as B from 'babylonjs';
import { scene } from './scene';

export function makeGround(): B.Mesh {
    const size: number = 15;
    const ground = B.MeshBuilder.CreateGround(
        "ground",
        {width: size, height: size},
        scene
    )

    const groundMat = new B.StandardMaterial("groundMat");
    groundMat.diffuseColor = new B.Color3(0, 1, 0);

    ground.physicsImpostor = new B.PhysicsImpostor(
        ground,
        B.PhysicsImpostor.BoxImpostor,
        {mass: 0, restitution: 0.9},
        scene
    )

    ground.material = groundMat;

    return ground;
    // const groundMat = new BABYLON.StandardMaterial("groundMat");
    // groundMat.diffuseColor = new BABYLON.Color3(0, 1, 0);

    // const ground = BABYLON.MeshBuilder.CreateGround("ground", {
    //     width: 20,
    //     height: 20,
    // });
    // ground.material = groundMat;
    
    // return ground;
}