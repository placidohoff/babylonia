import * as B from 'babylonjs'

var speed = 0.1;
let cube :B.Mesh;
cube = document.getElementById()

window.addEventListener("keydown", function (event) {
    var keyCode = event.keyCode;
    
    switch (keyCode) {
        case 87: // W key
            cube.position.z += speed;
            break;
        case 83: // S key
            cube.position.z -= speed;
            break;
        case 65: // A key
            cube.position.x -= speed;
            break;
        case 68: // D key
            cube.position.x += speed;
            break;
    }
});