import * as B from 'babylonjs';
import { scene } from './scene';

export function makeCube(): B.Mesh {
    const cube: B.Mesh = B.MeshBuilder.CreateBox('cube', { size: 0.5 });
    cube.position = new B.Vector3(0, 1, 0);

    //Adding mass will give it weight to drop from its start position of 1
    cube.physicsImpostor = new B.PhysicsImpostor(
        cube,
        B.PhysicsImpostor.BoxImpostor,
        {mass: 1, restitution: 0.9},
        scene
    )

    return cube;
}
