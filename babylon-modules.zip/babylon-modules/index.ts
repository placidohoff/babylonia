import * as B from 'babylonjs';
import 'regenerator-runtime/runtime';
import { scene, engine } from './src/scene';
import { makeGround } from './src/ground';
import { makeCube } from './src/cube';
import Ammo from 'ammojs-typed';
import { buildEnvironment } from './src/environment';
import { buildCar } from './src/car';

let cube: B.Mesh;

async function main(): Promise<void> {
    //Create an instance of Ammo:
    // const ammo = await Ammo();
    // //Declare and assign our phyics variable to be the Ammo instance.
    // const physics: B.AmmoJSPlugin = new B.AmmoJSPlugin(true, ammo);
    // //Apply our physics variable to the scene
    // scene.enablePhysics(new B.Vector3(0, -9.81, 0), physics);

    //Create object and ground
    // cube = makeCube();
    makeGround();
    buildEnvironment();
    buildCar(scene);

    const car: B.AbstractMesh | null = scene.getMeshByName("car");


    // // car.rotation = new B.Vector3(Math.PI / 2, 0, -Math.PI / 2);
    // car.rotation = new B.Vector3(-Math.PI / 2, -Math.PI / 2, Math.PI / 2);
    // // car.rotation.y -= Math.PI / 2;
    // // car.rotation = new B.Vector3(B.Axis.Y, -Math.PI / 2, BABYLON.Space.LOCAL);
    // car.position._y = 0.16;
    // car.position._x = 10  ;
    // car.position.z = 8;
    console.log(car.position);


    //Call the scene's game loop
    engine.runRenderLoop(() => scene.render());
}

var speed = 0.1;

//Keydown handler:
window.addEventListener("keydown", function (event) {
    var keyCode = event.keyCode;

    switch (keyCode) {
        case 87: // W key
            cube.position.z += speed;
            break;
        case 83: // S key
            cube.position.z -= speed;
            break;
        case 65: // A key
            cube.position.x -= speed;
            break;
        case 68: // D key
            cube.position.x += speed;
            break;
    }
});

// Watch for browser/canvas resize events
window.addEventListener("resize", function () {
    engine.resize();
});


main();