import {
  Engine,
  Scene,
  ArcRotateCamera,
  Vector3,
  HemisphericLight,
  Mesh,
  MeshBuilder,
  Color4,
  FreeCamera,
  Observable,
} from "@babylonjs/core";
import { AdvancedDynamicTexture, Button, Control } from "@babylonjs/gui";

export class GameOverScene extends Scene {
  private engine: Engine;

  public onNextButtonClick = new Observable<void>();

  private handleNextButtonClick() {
    this.onNextButtonClick.notifyObservers();
  }

  constructor(engine: Engine) {
    super(engine);
    this.engine = engine;

    this.clearColor = new Color4(0, 0, 0, 1);
  }

  public async setupScene(): Promise<void> {
    //loading module while scene loads:
    this.engine.displayLoadingUI();

    //detatch current scene:
    // this.scene.detachControl();

    let camera = new FreeCamera("camera1", new Vector3(0, 0, 0), this);
    camera.setTarget(Vector3.Zero());

    //Create the GUI:
    const guiMenu = AdvancedDynamicTexture.CreateFullscreenUI("UI");
    const mainBtn = Button.CreateSimpleButton("mainmenu", "MAIN MENU");
    mainBtn.width = 0.2;
    mainBtn.height = "40px";
    mainBtn.color = "white";
    guiMenu.addControl(mainBtn);
    //Add observable much like an onClick:
    // Handle interactions with the start button attached to the scene:
    mainBtn.onPointerDownObservable.add(() => {
      // Handle button click logic here
      //   console.log("test");
      this.handleNextButtonClick();
    });

    //Await until scene is ready, then proceed:
    await this.whenReadyAsync();

    this.engine.hideLoadingUI();
  }
}
