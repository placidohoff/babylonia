import {
  Engine,
  Scene,
  ArcRotateCamera,
  Vector3,
  HemisphericLight,
  Mesh,
  MeshBuilder,
  Color4,
  FreeCamera,
  Observable,
} from "@babylonjs/core";
import { AdvancedDynamicTexture, Button, Control } from "@babylonjs/gui";

export class GameScene extends Scene {
  private engine: Engine;

  public onNextButtonClick = new Observable<void>();

  private handleNextButtonClick() {
    this.onNextButtonClick.notifyObservers();
  }

  constructor(engine: Engine) {
    super(engine);
    this.engine = engine;

    this.clearColor = new Color4(
      0.01568627450980392,
      0.01568627450980392,
      0.20392156862745098
    );
  }

  public async setupScene(): Promise<void> {
    // Display loading UI while the screen is loading:
    this.engine.displayLoadingUI();

    // Create a camera and set its position/target:
    let camera: ArcRotateCamera = new ArcRotateCamera(
      "Camera",
      Math.PI / 2,
      Math.PI / 2,
      2,
      Vector3.Zero(),
      this
    );
    camera.setTarget(Vector3.Zero());

    // CREATE THE GUI FOR THIS SCENE:
    const playerUI = AdvancedDynamicTexture.CreateFullscreenUI("UI");
    //dont detect any inputs from this ui while the game is loading
    this.detachControl();

    //create a simple button
    const loseBtn = Button.CreateSimpleButton("lose", "LOSE");
    loseBtn.width = 0.2;
    loseBtn.height = "40px";
    loseBtn.color = "white";
    loseBtn.top = "-14px";
    loseBtn.thickness = 0;
    loseBtn.verticalAlignment = Control.VERTICAL_ALIGNMENT_BOTTOM;
    playerUI.addControl(loseBtn);

    // Handle interactions with the start button attached to the scene:
    loseBtn.onPointerDownObservable.add(() => {
      // Handle button click logic here
      //   console.log("test");
      this.handleNextButtonClick();
    });

    //temporary scene objects
    var light1: HemisphericLight = new HemisphericLight(
      "light1",
      new Vector3(1, 1, 0),
      this
    );
    var sphere: Mesh = MeshBuilder.CreateSphere(
      "sphere",
      { diameter: 1 },
      this
    );

    // When the scene is ready, hide the loading UI and dispose of the stored scene and load the new scene:
    await this.whenReadyAsync();
    this.engine.hideLoadingUI();
    this.attachControl();
    // //--START LOADING AND SETTING UP THE GAME DURING THIS SCENE--
    // var finishedLoading = false;
    // await this._setUpGame().then((res) => {
    //   finishedLoading = true;
    // });
  }

  //     private async _setUpGame(): Promise<void> {
  //       let scene = new Scene(this.engine);
  //     //   this._gamescene = scene;

  //       //TODO: Load assets
  //       const environment = new Environment(scene);
  //       this._environment = environment;

  //       //Load the environment:
  //       await this._environment.load();

  //       //Load the character:
  //       await this._loadCharacterAssets(scene);
  //     }
}
