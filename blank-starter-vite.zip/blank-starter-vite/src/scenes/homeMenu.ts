import {
  Engine,
  Scene,
  ArcRotateCamera,
  Vector3,
  HemisphericLight,
  Mesh,
  MeshBuilder,
  Color4,
  FreeCamera,
  Observable,
} from "@babylonjs/core";
import { AdvancedDynamicTexture, Button, Control } from "@babylonjs/gui";

export class HomeMenu extends Scene {
  private engine: Engine;

  public onStartButtonClick = new Observable<void>();

  private handleStartButtonClick() {
    this.onStartButtonClick.notifyObservers();
  }

  constructor(engine: Engine) {
    super(engine);
    this.engine = engine;

    this.clearColor = new Color4(0, 0, 0, 1);
  }

  public async setupScene(): Promise<void> {
    // Display loading UI while the screen is loading:
    this.engine.displayLoadingUI();

    // Create a camera and set its position/target:
    const camera = new FreeCamera("camera1", new Vector3(0, 0, 0), this);
    camera.setTarget(Vector3.Zero());

    // CREATE THE GUI FOR THIS SCENE:
    const guiMenu = AdvancedDynamicTexture.CreateFullscreenUI("UI");
    guiMenu.idealHeight = 720;

    // Create a simple button:
    const startBtn = Button.CreateSimpleButton("start", "PLAY");
    startBtn.width = 0.2;
    startBtn.height = "40px";
    startBtn.color = "white";
    startBtn.top = "-14px";
    startBtn.thickness = 0;
    startBtn.verticalAlignment = Control.VERTICAL_ALIGNMENT_BOTTOM;
    guiMenu.addControl(startBtn);

    // Handle interactions with the start button attached to the scene:
    startBtn.onPointerDownObservable.add(() => {
      // Handle button click logic here
      //   console.log("test");
      this.handleStartButtonClick();
    });

    // When the scene is ready, hide the loading UI and dispose of the stored scene and load the new scene:
    await this.whenReadyAsync();
    this.engine.hideLoadingUI();
  }
}
