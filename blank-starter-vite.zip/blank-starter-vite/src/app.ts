import "@babylonjs/core/Debug/debugLayer";
import {
  Engine,
  Scene,
  ArcRotateCamera,
  Vector3,
  HemisphericLight,
  Mesh,
  MeshBuilder,
  Color4,
  FreeCamera,
} from "@babylonjs/core";
import { AdvancedDynamicTexture, Button, Control } from "@babylonjs/gui";
import { HomeMenu } from "./scenes/homeMenu";
import { CutScene } from "./scenes/cutScene";
import { GameScene } from "./scenes/gameScene";
import { GameOverScene } from "./scenes/gameOverScene";

enum State {
  START = 0,
  GAME = 1,
  LOSE = 2,
  CUTSCENE = 3,
}

class App {
  private _scene: Scene;
  private _canvas: HTMLCanvasElement;
  private _engine: Engine;
  //   private _environment: Environment;

  //Keep track of the state to render:
  private _state: Number = 0;

  private _assets;

  private _createCanvas(): HTMLCanvasElement {
    //Commented out for development
    document.documentElement.style["overflow"] = "hidden";
    document.documentElement.style.overflow = "hidden";
    document.documentElement.style.width = "100%";
    document.documentElement.style.height = "100%";
    document.documentElement.style.margin = "0";
    document.documentElement.style.padding = "0";
    document.body.style.overflow = "hidden";
    document.body.style.width = "100%";
    document.body.style.height = "100%";
    document.body.style.margin = "0";
    document.body.style.padding = "0";

    //create the canvas html element and attach it to the webpage
    this._canvas = document.createElement("canvas");
    this._canvas.style.width = "100%";
    this._canvas.style.height = "100%";
    this._canvas.id = "gameCanvas";
    document.body.appendChild(this._canvas);

    return this._canvas;
  }

  constructor() {
    // create the canvas html element and attach it to the webpage
    this._canvas = this._createCanvas();

    // initialize babylon scene and engine
    this._engine = new Engine(this._canvas, true);
    this._scene = new Scene(this._engine);

    var camera: ArcRotateCamera = new ArcRotateCamera(
      "Camera",
      Math.PI / 2,
      Math.PI / 2,
      2,
      Vector3.Zero(),
      this._scene
    );
    camera.attachControl(this._canvas, true);
    var light1: HemisphericLight = new HemisphericLight(
      "light1",
      new Vector3(1, 1, 0),
      this._scene
    );
    var sphere: Mesh = MeshBuilder.CreateSphere(
      "sphere",
      { diameter: 1 },
      this._scene
    );

    // hide/show the Inspector
    window.addEventListener("keydown", (ev) => {
      // Shift+Ctrl+Alt+I
      if (ev.shiftKey && ev.ctrlKey && ev.altKey && ev.keyCode === 73) {
        if (this._scene.debugLayer.isVisible()) {
          this._scene.debugLayer.hide();
        } else {
          this._scene.debugLayer.show();
        }
      }
    });

    this._main();
  }

  private async _main(): Promise<void> {
    await this._goToStart();

    this._engine.runRenderLoop(() => {
      switch (this._state) {
        case State.START:
          this._scene.render();
          break;
        case State.CUTSCENE:
          this._scene.render();
          break;
        case State.GAME:
          this._scene.render();
          break;
        case State.LOSE:
          this._scene.render();
          break;
        default:
          break;
      }
    });

    //resize if the screen is resized/rotated
    window.addEventListener("resize", () => {
      this._engine.resize();
    });
  }

  private async _goToStart(): Promise<void> {
    const homeMenu = new HomeMenu(this._engine);
    homeMenu.setupScene();
    homeMenu.onStartButtonClick.add(() => {
      this._goToCutScene();
    });
    // run the main render loop
    this._scene = homeMenu;
  }

  private async _goToCutScene(): Promise<void> {
    const cutScene = new CutScene(this._engine);
    cutScene.setupScene();
    cutScene.onNextButtonClick.add(() => {
      this._goToGameScene();
    });
    // Logic for changing scenes:
    this._scene.dispose();
    this._state = State.CUTSCENE;
    this._scene = cutScene;
  }

  private async _goToGameScene(): Promise<void> {
    const gameScene = new GameScene(this._engine);
    gameScene.setupScene();
    gameScene.onNextButtonClick.add(() => {
      this._goToLoseScene();
    });
    // Logic for changing scenes:
    this._scene.dispose();
    this._state = State.GAME;
    this._scene = gameScene;
  }

  private async _goToLoseScene(): Promise<void> {
    const loseScene = new GameOverScene(this._engine);
    loseScene.setupScene();
    loseScene.onNextButtonClick.add(() => {
      this._goToStart();
    });
    // Logic for changing scenes:
    this._scene.dispose();
    this._state = State.LOSE;
    this._scene = loseScene;
  }

  //Start/home screen:
  //   private async _goToStart(): Promise<void> {
  //     //Display loading UI while screen is loading:
  //     this._engine.displayLoadingUI();

  //     //Create the scene and camera, set the origin of camera to center of scene:
  //     this._scene.detachControl();
  //     let scene = new Scene(this._engine);
  //     scene.clearColor = new Color4(0, 0, 0, 1);
  //     let camera = new FreeCamera("camera1", new Vector3(0, 0, 0), scene);
  //     camera.setTarget(Vector3.Zero());

  //     //CREATE THE GUI FOR THIS SCENE:
  //     const guiMenu = AdvancedDynamicTexture.CreateFullscreenUI("UI");
  //     guiMenu.idealHeight = 720;

  //     //create a simple button:
  //     const startBtn = Button.CreateSimpleButton("start", "PLAY");
  //     startBtn.width = 0.2;
  //     startBtn.height = "40px";
  //     startBtn.color = "white";
  //     startBtn.top = "-14px";
  //     startBtn.thickness = 0;
  //     startBtn.verticalAlignment = Control.VERTICAL_ALIGNMENT_BOTTOM;
  //     guiMenu.addControl(startBtn);

  //     //this handles interactions with start button attached to the scene:
  //     startBtn.onPointerDownObservable.add(() => {
  //       //   this._goToCutScene();
  //       //observables disabled:
  //       //   scene.detachControl();
  //       console.log("test");
  //     });

  //     //When scene is ready, hide the loading UI and dispose of the stored scene and load the new scene:
  //     await scene.whenReadyAsync();
  //     this._engine.hideLoadingUI();
  //     //Stop and swap scenes:
  //     this._scene.dispose();
  //     this._scene = scene;
  //     this._state = State.START;
  //   }
}
new App();
